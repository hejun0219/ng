# 快速开始



## 使用`arthas-boot`(推荐)

这是是执行java-jar命令后自动帮你下载好，直接导入文件不用

下载`arthas-boot.jar`，然后用`java -jar`的方式启动：

```
curl -O https://arthas.aliyun.com/arthas-boot.jar
java -jar arthas-boot.jar
```



打印帮助信息：

```
java -jar arthas-boot.jar -h
```



- 如果下载速度比较慢，可以使用aliyun的镜像：`java -jar arthas-boot.jar --repo-mirror aliyun --use-http`

## 直接导入文件

直接上传，java -jar arthas-boot.jar就行了



