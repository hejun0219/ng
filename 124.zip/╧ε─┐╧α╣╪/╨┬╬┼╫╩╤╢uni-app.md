# 1.搭建uni-app环境

使用vue-cli进行构建环境

```shell
vue create -p dcloudio/uni-preset-vue my_news
```

![å¨è¿éæå¥å¾çæè¿°](../imgs/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA5piM5piM6Ium57uD6IOM5ZCO,size_20,color_FFFFFF,t_70,g_se,x_16.png)

![å¨è¿éæå¥å¾çæè¿°](../imgs/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA5piM5piM6Ium57uD6IOM5ZCO,size_18,color_FFFFFF,t_70,g_se,x_16.png)

![å¨è¿éæå¥å¾çæè¿°](../imgs/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA5piM5piM6Ium57uD6IOM5ZCO,size_17,color_FFFFFF,t_70,g_se,x_16.png)

如果报上面的错就加这一行话

# 2 uniapp基础语法

## 2.1 基础绑定

v-bind:class绑定    v-bind简写是 :

v-on:click="" v-on绑定事件  v-on简写是@

## 2.2 uniapp中的this

```html
onLoad() {
    setTimeout(args => {
      this.title = '江豪迪最帅'
    },2000)
},
```



## 2.3 v-if,v-else

![image-20220117120436978](../imgs/image-20220117120436978.png)

## 2.4 v-for

```vue
<view v-for="item in arr" >
  {{item}}
</view>
```

## 2.5 自定义组件

### 1.注册一个组件

```vue
<template>
  <view class="clickBtn" :style="{color:color}">
    点击
  </view>
</template>

<script>
export default {
	props:{
		color:{
			type:String,
			default:'#000'
		}
	}
}
</script>

<style>
  .clickBtn {
    width: 40px;
    height: 40px;
    border: 1px solid #4cd964;
  }

</style>

```

props用来表示掉用组件方可以传入的参数

### 2.调用组件

#### 2.1 引入组件

```vue
 import btn from "@/component/btn/btn";
	export default {
    components:{
      btn
    },
```

#### 2.2 使用

```vue
<btn color="red"></btn>
```

### 3 组件中使用事件

![image-20220117164927389](../imgs/image-20220117164927389.png)

可以进行接收

![image-20220117170057901](../imgs/image-20220117170057901.png)

### 4 slot的用法

组件调用方加入

```vue
<view class="clickBtn" :style="{color:color} " @click="change">
    <slot></slot>
  </view>
```

# 3 去除默认的导航栏

```vue
{
			"path": "pages/index/index",
			"style": {
				"navigationBarTitleText": "uni-app",
				"navigationStyle":"custom"
			}
		}
```



# 4 导航栏制作

## 4.1 对导航栏进行固定

```css
.navbar{
		//进行固定
		position: fixed;
		z-index: 999;
```

## 4.2 隐藏滚动条

```css
& ::-webkit-scrollbar{
			width: 0;
			height: 0;
			background-color: transparent;
		}
```

## 4.3 不让文字竖着

flex-shrink: 0;

## 4.4 uni-app字体插件

https://ext.dcloud.net.cn/search?q=Icons%E5%9B%BE%E6%A0%87

![image-20220119151712187](../imgs/image-20220119151712187.png)

```css
<text><uni-icons type="search" size="20"></uni-icons></text>
```

# 5 导航栏动态添加class

```vue
<view v-for="(item,index) in list" :class="{active:index===currentNewsTypeIndex}" @click="typeClick(index)">
 {{item.newsTypeName}}
</view>
```
