docker commit  -a "xiaodidi" -m "save" 容器id 镜像名称

也可以使用docker import来导入镜像

docker-compose同一网段可以使用名字：端口的方式进行访问

docker可以直接关闭防火墙，不受外部控制，如果要进行控制，需要开始就进行关闭





