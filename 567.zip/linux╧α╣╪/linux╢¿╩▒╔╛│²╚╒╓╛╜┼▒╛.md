# 1.自动删除nginx日志

```shell
#!/bin/sh
NGINXPATH=/home/lantone/nginx

mv $NGINXPATH/logs/access.log $NGINXPATH/logs/access.log_$(date -d "yesterday" +"%Y-%m-%d")
rm -rf $NGINXPATH/logs/access.log_$(date -d "30 days ago" +"%Y-%m-%d")
touch $NGINXPATH/logs/access.log
chmod 755 $NGINXPATH/logs/access.log
$NGINXPATH/sbin/nginx -s reload
mkdir -p /xiaodidi/top
```