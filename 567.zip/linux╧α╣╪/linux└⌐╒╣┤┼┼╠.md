Linux在使用过程中由于数据量不断增大，导致磁盘空间不足，需要增加磁盘空间，主要有以下三种方式  
1、直接给 / 分区（或者某一分区）扩容，直接在原有磁盘上增大空间  
2、给[虚拟机](https://so.csdn.net/so/search?q=%E8%99%9A%E6%8B%9F%E6%9C%BA&spm=1001.2101.3001.7020)新增一块磁盘，为这块磁盘新建一个分区  
3、给虚拟机新增一块磁盘，并把磁盘空间扩容到原有分区00

### 1、给 / 分区扩容

查看磁盘空间大小，目前 / 分区大小为50G，并且只有一块磁盘![在这里插入图片描述](imgs/20201118092458520-16686756083851.png%23pic_center)  
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201118092644593.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70#pic_center)  
给/dev/vda 增加50G的空间，并把这50G扩容到 / 分区  
![在这里插入图片描述](imgs/20201118092852176-16686756153923.png%23pic_center)  
/dev/vda 目前为100G，接下来对磁盘进行分区，创建物理卷，把新增的物理卷加到卷组里  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center.png)  
对磁盘分区，使用fdisk /dev/vda ，输入n 新建分区，然后一直回车，最后输入 w 保存配置；创建完成之后，可输入 p 查看；/dev/vda3 即为新建的分区  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-16686756555776.png)  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-16686756589418.png)  
输入partprobe 让系统识别新增的分区，然后创建物理卷，使用pvcreate /dev/vda3![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867567037212.png)  
扩展卷组，使用vgextend centos /dev/vda3命令，卷组信息可通过 vgdisplay 查看  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867567433914.png)  
扩展 / 的大小，增加50G，使用lvresize \-L +30G /dev/mapper/centos-root命令，其中  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867567664316.png)  
重新识别 / 分区的大小，而ext4格式磁盘使用resize2fs /dev/mapper/centos-root  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867568153018.png)

### 2、新增一块磁盘并划分独立分区,新增一块100G的磁盘，划分为/data

![在这里插入图片描述](imgs/20201118094827693-166867568407420.png%23pic_center)  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867568637322.png)  
对磁盘 /dev/vdb 进行分区，格式化，挂载  
磁盘分区  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867568824924.png)  
格式化  
![在这里插入图片描述](imgs/20201118095127120-166867569086926.png%23pic_center)  
创建挂载点 /data，挂载分区  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867569289428.png)  
实现开机自动挂载（编辑 /etc/fstab 文件），保存退出后，执行 mount \-a 无报错则配置成功  
![在这里插入图片描述](imgs/20201118095411731-166867569534830.png%23pic_center)

### 3、新增一块磁盘，并扩容到原有分区

新增一块磁盘 /dev/vdc 大小为50G，并把空间扩容至 / 分区  
![在这里插入图片描述](imgs/20201118095818211-166867569738632.png%23pic_center)  
对 /dev/vdc 进行分区，并设置分区属性  
t: 修改分区文件系统id，选择8e，LVM（与原有分区一致）  
L：列出所有Hex代码  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867569929334.png)  
输入partprobe 让系统识别新增的分区，然后创建物理卷，使用pvcreate /dev/vdc1；pvdisplay查看  
![在这里插入图片描述](imgs/2020111810390526-166867570209936.png%23pic_center)  
扩展卷组，扩展分区  
![在这里插入图片描述](imgs/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70%23pic_center-166867570414438.png)  
查看磁盘大小  
![在这里插入图片描述](imgs/2020111810412355-166867570715940.png%23pic_center)

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201118104138274.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0hscm9saXU=,size_16,color_FFFFFF,t_70#pic_center)