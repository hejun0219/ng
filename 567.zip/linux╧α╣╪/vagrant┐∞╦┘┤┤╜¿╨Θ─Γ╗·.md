# 1.安装vagrant和virtualBox

一直点下一步就行

# 2.修改virtualBox配置

![image-20220830150659929](imgs/image-20220830150659929.png)

# 3.初始化虚拟机

```powershell
vagrant init centos7 https://mirrors.ustc.edu.cn/centos-cloud/centos/7/vagrant/x86_64/images/CentOS-7-x86_64-Vagrant-1805_01.VirtualBox.box
```

```
vagrant up#需要等待下载
```

https://mirrors.ustc.edu.cn/centos-cloud/centos/7/vagrant/x86_64/images/CentOS-7-x86_64-Vagrant-2004_01.VirtualBox.box 

# 4.修改内存处理器

修改内存处理器的配置

```
config.vm.provider "virtualbox" do |v|
  v.memory = 12288
  v.cpus = 4
  end
```

记得把这个关掉，不让映射

```
config.vm.synced_folder ".", "/vagrant", disabled: true  
```





# 5.修改网络配置



设置桥接网卡

![image-20220925111332541](imgs/image-20220925111332541.png)



```
config.vm.network "public_network",bridge: "Realtek PCIe GbE Family Controller",ip: "192.168.124.100"
```



# 6.建立root用户



Vagarnt VirtualBox
ssh登录默认生成是账号vagrant，密码vagrant。
要安装docker，要root账号，所以这里创建root账号。
1、切换到root，修改sshd_config

```shell
[vagrant@localhost ~]$ sudo -s
[root@localhost vagrant]#
[root@localhost vagrant]# vi /etc/ssh/sshd_config
```


找到PermitRootLogin，去掉前面的#号，开启yes

```
PermitRootLogin yes
```




找到PasswordAuthentication ，去掉前面的#号，开启yes

>PasswordAuthentication yes
>修改完，wq保存退出。
>2、重启ssh服务：
>执行：
>service sshd restart





# 7.快速创建docker和docker-compose



```shell
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
yum install docker-ce docker-ce-cli containerd.io
systemctl start docker
systemctl enable docker
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

```





