# 1.安装Kuboard Spray

```sh
docker run -d   --privileged   --restart=unless-stopped   --name=kuboard-spray   -p 80:80/tcp   -e TZ=Asia/Shanghai   -v /var/run/docker.sock:/var/run/docker.sock   -v ~/kuboard-spray-data:/data   eipwork/kuboard-spray:v1.0.1-amd64
  # 如果您是 arm64 环境，请将标签里的 amd64 修改为 arm64，例如 eipwork/kuboard-spray:latest-arm64
  # 如果抓不到这个镜像，可以尝试一下这个备用地址：
  # swr.cn-east-2.myhuaweicloud.com/kuboard/kuboard-spray:latest-amd64

```

# 2.导入资源包



![加载 Kuboard-Spray 资源包](imgs/kuboard-spray-01.a2293876.png)



![image-20240325141219987](imgs/image-20240325141219987.png)

## 3.规划并安装集群

- 在 Kuboard-Spray 界面中，导航到 `集群管理` 界面，点击界面中的 `添加集群安装计划` 按钮，填写表单如下：
  - 集群名称： 自定义名称，本文中填写为 kuboard123，此名称不可以修改；
  - 资源包：选择前面步骤中导入的离线资源包。

![创建集群安装计划](imgs/kuboard-spray-02.1fd287d4.png)

点击上图对话框中的 `确定` 按钮后，将进入集群规划页面，在该界面中添加您每个集群节点的连接参数并设置节点的角色，如下图所示：

重要： kuboard-spray 所在机器不能当做 K8S 集群的一个节点，因为安装过程中会重启集群节点的容器引擎，这会导致 kuboard-spray 被重启掉。

![集群规划](imgs/kuboard-spray-03.f4770478.png)

::: tip 注意事项

- 最少的节点数量是 1 个；

- ETCD 节点、控制节点的总数量必须为奇数；

- 在 `全局设置` 标签页，可以设置节点的通用连接参数，例如所有的节点都使用相同的 ssh 端口、用户名、密码，则共同的参数只在此处设置即可；

- 在节点标签页，如果该节点的角色包含 `etcd` 则必须填写 `ETCD 成员名称` 这个字段；

- 如果您 KuboardSpray 所在节点不能直接访问到 Kubernetes 集群的节点，您可以设置跳板机参数，使 KuboardSpray 可以通过 ssh 访问集群节点。

- 集群安装过程中，除了已经导入的资源包以外，还需要使用 yum 或 apt 指令安装一些系统软件，例如 curl, rsync, ipvadm, ipset, ethtool 等，此时要用到操作系统的 apt 软件源或者 yum 软件源。

  ```
  全局设置
  ```

   

  标签页中，可以引导您完成 apt / yum 软件源的设置，您可以：

  - 使用节点操作系统已经事先配置的 apt / yum 源，或者
  - 在安装过程中自动配置节点的操作系统使用指定的软件源

- 如果您使用 docker 作为集群的容器引擎，还需要在

   

  ```
  全局设置
  ```

   

  标签页指定安装 docker 用的 apt / yum 源。

  > 如果您使用 containerd 作为容器引擎，则无需配置 docker 的 apt / yum 源，containerd 的安装包已经包含在 KuboardSpray 离线资源包中。

点击上图的 `保存` 按钮，再点击 `执行` 按钮，可以启动集群的离线安装过程，如下图所示：

![集群安装](imgs/kuboard-spray-04.0592463d.png)