# java语句的技巧

## 1 取反的快捷方式

```javascript
this.checked = !this.checked;
```

## 2 判断语句合并

```javascript
$("#checkedAllBox").prop("checked",length === length1);
```

```javascript
if (this.checked){

   $(":checkbox:not(#checkedAllBox)").prop("checked", true);
} else {
   $(":checkbox:not(#checkedAllBox)").prop("checked", false);

}
```

变为

```javascript
$(":checkbox:not(#checkedAllBox)").prop("checked", this.checked);
```

## 3 空字符串的ascll码最小

在学习一门新的技术的时候，需要在网上先找一个例子，然后通过文档对照着进行学习



## 4 isAssignableForm

假设有两个类Class1和Class2。`Class1.isAssignableFrom(Class2)`表示:

1.  类Class1和Class2是否相同。
2.  Class1是否是Class2的父类或接口
    调用者和参数都是java.lang.Class类型。



## 5 循环结束外层

```java

public class TestLoop {
    @Test
    public void loop(){
        xiaodidi:
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 5; j++) {
                if (j == 3) {
                    continue xiaodidi;
                }
                System.out.println(i+""+j);
            }

        }
    }
}
```



## 6 随机带时间的id

使用mybatis-plus的idworker工具类

中的timeId

## 7 Transcation注解失效

　　spring的@Transactional事务生效的一个前提是进行方法调用前经过拦截器TransactionInterceptor；

　　Spring采用动态代理(AOP)实现对bean的管理和切片，它为每个class生成一个代理对象。在代理对象之间进行调用时，可以触发切面逻辑。而在同一个class中，方法B调用方法A，调用的是原对象的方法，而不通过代理对象。所以Spring无法拦截到这次调用，也就无法通过注解保证事务性了，所以，在同一个类中的方法调用，则不会被方法拦截器拦截到，因此事务不会起作用。例如：在同一个类中调用被声明的事务方法，如下

　　　　![img](imgs/1485963-20200905095349634-285751395.png)

 

 

 　

解决方法：

　　1、可以将方法放入另一个类，并且该类通过spring注入，即符合了在对象之间调用的条件

　　2、获取本对象的代理对象，再进行调用。

　　　　1）Spring-content.xml上下文中，增加配置：<aop:aspectj-autoproxy expose-proxy=“true”/>

　　　　2）在xxxServiceImpl中，用(xxxService)(AopContext.currentProxy())，获取到xxxService的代理类，再调用事务方法，强行经过代理类，激活事务切面。
　　　![img](imgs/1485963-20200905095801105-1827046414.png)

 

##  8 拦截恶意请求访问

该例子需要用到 redis 

在applocation.properties中加入redis的配置信息

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

```
server.port=8030

# Redis数据库索引（默认为0）
spring.redis.database=0 
# Redis服务器地址
spring.redis.host=localhost
# Redis服务器连接端口
spring.redis.port=6379 
# Redis服务器连接密码（默认为空）
spring.redis.password=
#连接池最大连接数（使用负值表示没有限制）
spring.redis.jedis.pool.max-idle=8 
# 连接池最大阻塞等待时间（使用负值表示没有限制）
spring.redis.jedis.pool.max-wait=
# 连接池中的最大空闲连接
spring.redis.jedis..pool.max-idle=8 
# 连接池中的最小空闲连接
spring.redis.jedis.pool.min-idle=0 
# 连接超时时间（毫秒）
spring.redis.timeout=300
 
```

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

 

RedisConfig.java

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

```
package cn.rc.config;

import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@EnableCaching // 开启注解
public class RedisConfig extends CachingConfigurerSupport {

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {

        RedisTemplate<String, Object> template = new RedisTemplate<>();
        // 配置连接工厂
        template.setConnectionFactory(factory);

        // 使用Jackson2JsonRedisSerializer来序列化和反序列化redis的value值（默认使用JDK的序列化方式）
        Jackson2JsonRedisSerializer jacksonSeial = new Jackson2JsonRedisSerializer(Object.class);

        ObjectMapper om = new ObjectMapper();
        // 指定要序列化的域，field,get和set,以及修饰符范围，ANY是都有包括private和public
        om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        // 指定序列化输入的类型，类必须是非final修饰的，final修饰的类，比如String,Integer等会跑出异常
        om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        jacksonSeial.setObjectMapper(om);

        // 值采用json序列化
        template.setValueSerializer(jacksonSeial);
        // 使用StringRedisSerializer来序列化和反序列化redis的key值
        template.setKeySerializer(new StringRedisSerializer());

        // 设置hash key 和value序列化模式
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(jacksonSeial);
        template.afterPropertiesSet();

        return template;
    }
}
```

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

 

需要先启动redis功能

 

一、声明一个自定义的注解类

```
AccessLimit.java
```

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

```
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface AccessLimit {
    int seconds();
    int maxCount();
    boolean needLogin() default true;
}
```

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

 

二、声明一个自定义的拦截器：

AccessLimtInterceptor.java 

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

```
@Component
public class AccessLimtInterceptor implements HandlerInterceptor {

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        if (handler instanceof HandlerMethod) {
            HandlerMethod hm = (HandlerMethod) handler;
            AccessLimit accessLimit = hm.getMethodAnnotation(AccessLimit.class);
            if (null == accessLimit) {
                return true;
            }
            int seconds = accessLimit.seconds();
            int maxCount = accessLimit.maxCount();
            boolean needLogin = accessLimit.needLogin();

            if (needLogin) {
                //判断是否登录
            }
            String ip=request.getRemoteAddr();
            String key = request.getServletPath() + ":" + ip ;
            Integer count = (Integer) redisTemplate.opsForValue().get(key);

            if (null == count || -1 == count) {
                redisTemplate.opsForValue().set(key, 1,seconds, TimeUnit.SECONDS);
                return true;
            }

            if (count < maxCount) {
                count = count+1;
                redisTemplate.opsForValue().set(key, count,0);
                return true;
            }

            if (count >= maxCount) {
//                response 返回 json 请求过于频繁请稍后再试
                response.setCharacterEncoding("UTF-8");
                response.setContentType("application/json; charset=utf-8");
                JsonResponse  result = new JsonResponse<>();
                result.setCode(9999);
                result.setMessage("操作过于频繁");
                Object obj = JSONObject.toJSON(result);
                response.getWriter().write(JSONObject.toJSONString(obj));
                return false;
            }
        }

        return true;
    }
}
```

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

 

将 拦截器 注册到容器：WebMvcConfig.java

 

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

```
/**
 * MVC 设置
 *
 */
@Configuration
public class WebMvcConfig extends WebMvcConfigurerAdapter {
    @Autowired
    private AccessLimtInterceptor accessLimtInterceptor;
    @Bean
    public AccessTokenVerifyInterceptor tokenVerifyInterceptor() {
        return new AccessTokenVerifyInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(accessLimtInterceptor);
        registry.addInterceptor(tokenVerifyInterceptor()).addPathPatterns("/**");
        super.addInterceptors(registry);
    }

}
```

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

 

进行测试接口:

使用 @AccessLimit(seconds = 15, maxCount = 3) 注解 修饰接口 , 15秒 只允许访问3次

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

```
@RestController
@RequestMapping("test")
public class TestAccessLimitController {

    @GetMapping("accessLimit")
    @AccessLimit(seconds = 15, maxCount = 3) //15秒内 允许请求3次
    public String testAccessLimit() {

        return "success";
    }
}
```

[![复制代码](imgs/copycode.gif)](javascript:void(0);)

 

浏览器请求：http://localhost:8030/test/accessLimit

　　返回: success 

快速刷新多次后出现：

　　![img](imgs/1024212-20200527171011864-1256404354.png)

 





# 一些常用工具的使用



![image-20210129165626001](imgs/image-20210129165626001.png)

![image-20210129173151286](imgs/image-20210129173151286.png)

![image-20210129173409949](imgs/image-20210129173409949.png)



## typora的一些操作

页内超链接的实现

记得按ctrl键并点击进行跳转

[java语句的技巧](#java语句的技巧)



## 正则表达式匹配网站

https://tool.oschina.net/regex/

想必正则表达式的匹配是很多程序员要用到的，但当遇到非常复杂的匹配需求时，我们还是需要调试很多次的。

这里给大家推荐一个在线的正则表达式匹配网站，可以直接测试正则表达式的匹配结果，不用频繁操作程序，并且还可以替换相应文本。

重点： 这个网站里具有一些常用的正则表达式匹配代码，我们可以直接拿来使用。

![img](imgs/b8f22db8242382160bdbcb0f37ca34030ddeb53c.png@1320w_622h.webp)

点击一下右侧相应的正则，就可以获得相应的正则匹配代码。


## 网络请求自动代码编写

网络请求自动代码编写：https://curl.trillworks.com/


这个网站可是我真真真压箱底的网站！！！！做过爬虫的程序员都知道，我们在分析网页文件的请求时，会在开发者工具里查看浏览器请求过来的文件。

![img](imgs/cbcc9fe847313cf65ec3a4f101792b9f436777f5.png@1320w_622h.webp)



假设这个图中箭头指的文件里有我们需要的数据，我们需要自己拟一个请求，去获取里面的数据，但有时候我们不知道请求的时候需要携带什么参数，我们就可以用这个网络请求自动代码编写网站来帮我们拟一个请求。

我们先右键点击这个文件，点击鼠标所指的地方

![img](imgs/97cbeb324689b6ead90dd7062bf909111160d8fb.jpg@1320w_742h.webp)



然后将复制的内容粘贴到该网站的左侧，然后选择对应的编程语言，就可以在右侧自动生成我们想要的网络请求代码了，该代码里已经自动携带上了请求时需要携带的参数。

![img](imgs/054a76af030439fa940c1d2ebd445a49142fa4a6.png@1320w_560h.webp)





这个网站也支持很多语言的，例如node.js 、PHP等等

![img](imgs/a06e6fb96f96885f370585f514b98e5b2d028533.png@820w_826h.webp)





所以，这样就方便了我们爬虫时分析网页请求，节省了很多时间。



### 图片素材网站

（1）Pixabay：https://pixabay.com/zh/

Pixabay网站是一个支持中文搜索的免费可商用图库。

![img](imgs/882a8a79c7fdd7e33396d49291965aa9e9267ced.png@1320w_618h.webp)

（2）Unsplash：https://unsplash.com/

Unsplash网站的免费照片有很多，而且照片大多都是偏唯美，不过网站内是英文的，我们可以用浏览器自带的翻译功能改成中文的。
![img](imgs/2d5eb7bec94281be43268328dda0f64f898c8601.png@1320w_618h.webp)



（3）Cupcake：https://cupcake.nilssonlee.se/

Cupcake网站比较简洁，照片大多适合做背景图。它没有搜索功能，是直接下拉依次浏览的，并且照片也全部都是免费的。



![img](imgs/9994113110bf3245de3abeadb594c56053b995e3.png@1320w_880h.webp)



（4）Pexels：https://www.pexels.com/zh-cn/

Pexels网站页面也十分的好看，跟Pixabay也很类似，也可以通过搜索框中输入文字，得到想要的图片。
![img](imgs/f04ac9ada5628c02e1d70d9d425024b028ddfd4a.png@1320w_620h.webp)



## js代码加密保护

http://www.jshaman.com

![image-20210403190736715](imgs/image-20210403190736715.png)



![img](imgs/d1d16c70a7638e162463ec1baf942dc34ae2111b.png@1320w_628h.webp)



## 在线格式转化网站

迅捷在线转换器：https://app.xunjiepdf.com/

我们在平时会遇到很多文件转换的问题，比如 pdf 转 word，这些格式转换我们都需要充值会员或者下载某款app才能实现，我是觉得没有必要的，所以给大家推荐了这个网站，它可以实现很多文件的格式转换。

![img](imgs/63863dc1da0e28c50ac1b0de64ebace011912da9.png@1320w_618h.webp)



## 办公软件下载安装

http://www.zhanshaoyi.com/rjxz.html
因为很多软件的正版都需要钱，而且都特别的贵，对于有些用于平时学习使用的人来说，购买正版太费钱了，这个网站放了很多办公软件的破解版，我们可以在上面自行选择下载获得，都是无毒的放心使用。

![img](imgs/f2fea7140860a24c7ea36811e59d94651a03e321.png@1320w_618h.webp)



## icon图标网站（网站上面的小图标)

前端开发人员，经常会用到一些小图标，比如首页小图标 、个人中心小图标 、购物车小图标，我们都可以在接下来我推荐的网站上轻松获得。


![img](imgs/d8e14aaeaf1a33910d635ba4cff768a5384136bb.png@1320w_620h.webp)





![img](https://i0.hdslb.com/bfs/article/dc472fe5986407410832c94883124cad8a1b7012.png@1320w_618h.webp)



## html转换成md工具

https://sitdown.mdnice.com/Demo.html











# idea插件

## 1 idea插件安装步骤![image-20210202102653201](imgs/image-20210202102653201.png)

## 2 idea插件常用的安装

### grep console(更改控制台的颜色)

![image-20210202104720996](imgs/image-20210202104720996.png)

## **3 Alibaba Java Coding Guidelines**

根据alibaba开发手册进行代码规范


## 4 Key Promoter X的使用

![image-20210202110923531](imgs/image-20210202110923531.png)

## 5 Gsonformat

![image-20210202122711565](imgs/image-20210202122711565.png)

## **6 Stackoverflow** 

谷歌搜索引擎搜索遇到的问题

## **7 Mybatis-log-plugin**

在mybatis配置文件中添加下列

```xml
<configuration>
    <settings>
        <setting name="logImpl" value="org.apache.ibatis.logging.stdout.StdOutImpl" />
    </settings>


    <typeAliases>
        <package name="com.atguigu.crowd.po"/>
    </typeAliases>
    





</configuration>
```

用于在日志文件中转换



在springboot中使用

```java
mybatis-plus.configuration.log-impl=org.apache.ibatis.logging.stdout.StdouImpl
```



## 8 Free MyBatis plugiu

![image-20210202133613186](imgs/image-20210202133613186.png)

## 9 CodeGlance

缩略图

## 10 Maven Helper

查找和排除冲突依赖项

## 11 GenerateAllSetter

![image-20210202134401530](imgs/image-20210202134401530.png)

## 12 Lombok

Lombok能以简单的注解形式来简化java代码，提高开发人员的开发效率。例如开发中经常需要写的javabean，都需要花时间去添加相应的getter/setter，也许还要去写构造器、equals等方法，而且需要维护，当属性多时会出现大量的getter/setter方法，这些显得很冗长也没有太多技术含量，一旦修改属性，就容易出现忘记修改对应方法的失误。Lombok能通过注解的方式，在编译时自动为属性生成构造器、getter/setter、equals、hashcode、toString方法。

出现的神奇就是在源码中没有getter和setter方法，

![img](https://img-blog.csdnimg.cn/20190520145907516.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dpbjdzeXN0ZW0=,size_16,color_FFFFFF,t_70)

但是在编译生成的字节码文件中有getter和setter方法。这样就省去了手动重建这些代码的麻烦，使代码看起来更简洁些。

![img](https://img-blog.csdnimg.cn/20190520145926369.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dpbjdzeXN0ZW0=,size_16,color_FFFFFF,t_70)

在使用之前需要添加一下依赖：

```html
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <version>1.18.8</version>
    <scope>provided</scope>
</dependency>
```

## **13 Restfultoolkit**

Spring MVC网页开发的时候，我们都是通过requestmapping的方式来定义页面的URL地址的，为了找到这个地址我们一般都是cmd+shift+F的方式进行查找，大家都知道，我们URL的命名一个是类requestmapping+方法requestmapping，查找的时候还是有那么一点不方便的，restfultookit就能很方便的帮忙进行查找。

例如：我要找到/user/add 对应的controller,那么只要Ctrl+斜杠 ,（图片来自于网络）

![img](https:////upload-images.jianshu.io/upload_images/18688925-a222d70e403b59cd?imageMogr2/auto-orient/strip|imageView2/2/w/1080/format/webp)





就能直接定位到我们想要的controller。这个也是真心方便，当然restfultookit还为我们提供的其他的功能。根据我们的controller帮我们生成默认的测试数据，还能直接调用测试，这个可以是解决了我们每次postman调试数据时，自己傻傻的组装数据的的操作，这个更加清晰，比在console找数据包要方便多了。（图片来自于网络）

![img](https:////upload-images.jianshu.io/upload_images/18688925-066d454dd3e74328?imageMogr2/auto-orient/strip|imageView2/2/w/640/format/webp)

![image-20210219222013513](imgs/image-20210219222013513.png)





## 14 Jrebel

热部署工具

记得按照网上进行安装好后

![image-20210202155446537](imgs/image-20210202155446537.png)

![image-20210202155448909](imgs/image-20210202155448909.png)

## 15 translation

翻译

## 16 Rainbow Brackets

进行彩虹括号

## 17 codota

用来进行代码提示

还可以在使用快捷键（Ctrl + Shift + O）导航给定类的方法时触发搜索，并获得所选方法的最佳片段：

![img](https://pics4.baidu.com/feed/54fbb2fb43166d2228d89c7457cf0df29252d290.jpeg?token=0ea743d1cb89434421728953e6205d64&s=A3B27380EEEAB76C4E5AFD85030070CA)

直接搜索

从tool–>Codota Search..或快捷键ctrl+shift+Y。

![img](https://pics0.baidu.com/feed/b3119313b07eca802b59084080cf93d8a044832d.jpeg?token=86320c88b53529a100a21a0af22098df&s=FB82D10B5C06F2CA022581D60100D0B2)

## 18 MyBatisCodeHelperPro的使用

https://gejun123456.github.io/MyBatisCodeHelper-Pro/#/changelog 使用地址



# 一些功能的实现

## 1 jquery的on函数的使用

通过on函数,即可动态绑定对象

```java
$(function () {
  //第一个参数是
  $("#rolePage").on("click", ".update", function () {
    $("#updateModal").modal("show");
    //this表示正在调用这个对象的标签
    let name = $(this).parent().prev().text();
    $("#updateModal [name = roleName]").val(name);
    window.roleId = $(this).attr("id");
   
```



## 2 springcloud通过refresh更新配置文件

### 2.1 父工程

```xml
<?xml version="1.0" encoding="UTF-8"?>

<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.atguigu</groupId>
  <artifactId>springCloud5</artifactId>
  <packaging>pom</packaging>
  <version>1.0-SNAPSHOT</version>
  <modules>
    <module>cloud-provider-payment8001</module>
      <module>cloud-consumer-order80</module>
      <module>cloud-api-commons</module>
    <module>cloud-eureka-server7001</module>
      <module>cloud-provider-payment8004</module>
      <module>cloud-consumer-feign-hystrix-order80</module>
      <module>cloud-consumer-hystrix-dashboard9001</module>
      <module>cloud-gateway-gateway9527</module>
      <module>cloud-config-center-3344</module>
      <module>cloud-config-client-3355</module>
      <module>cloud-stream-rabbitmq-provider8801</module>
      <module>cloud-stream-rabbitmq-consumer8802</module>
      <module>cloudalibaba-provider-payment9001</module>
    <module>cloudalibaba-consumer-nacos-order83</module>
    <module>cloudalibaba-config-nacos-client3377</module>
  </modules>

  <!-- 统一管理jar包版本 -->
  <properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <maven.compiler.source>1.8</maven.compiler.source>
    <maven.compiler.target>1.8</maven.compiler.target>
    <junit.version>4.12</junit.version>
    <log4j.version>1.2.17</log4j.version>
    <lombok.version>1.16.18</lombok.version>
    <mysql.version>5.1.47</mysql.version>
    <druid.version>1.1.16</druid.version>
    <mybatis.spring.boot.version>1.3.0</mybatis.spring.boot.version>
  </properties>

  <!-- 子模块继承之后，提供作用：
      锁定版本+子modlue不用写groupId和version -->
  <dependencyManagement>
    <dependencies>
      <!--spring boot 2.2.2-->
      <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-dependencies</artifactId>
        <version>2.2.2.RELEASE</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
      <!--spring cloud Hoxton.SR1-->
      <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-dependencies</artifactId>
        <version>Hoxton.SR1</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
      <!--spring cloud alibaba 2.1.0.RELEASE-->
      <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-alibaba-dependencies</artifactId>
        <version>2.1.0.RELEASE</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
      <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>${mysql.version}</version>
      </dependency>
      <dependency>
        <groupId>com.alibaba</groupId>
        <artifactId>druid</artifactId>
        <version>${druid.version}</version>
      </dependency>
      <dependency>
        <groupId>org.mybatis.spring.boot</groupId>
        <artifactId>mybatis-spring-boot-starter</artifactId>
        <version>${mybatis.spring.boot.version}</version>
      </dependency>
      <dependency>
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>${junit.version}</version>
      </dependency>
      <dependency>
        <groupId>log4j</groupId>
        <artifactId>log4j</artifactId>
        <version>${log4j.version}</version>
      </dependency>
      <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <version>${lombok.version}</version>
        <optional>true</optional>
      </dependency>
    </dependencies>
  </dependencyManagement>

  <build>
    <plugins>
      <plugin>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-maven-plugin</artifactId>
        <configuration>
          <fork>true</fork>
          <addResources>true</addResources>
        </configuration>
      </plugin>
    </plugins>
  </build>

</project>
```

### 2.2 子工程pom

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <parent>
        <artifactId>springCloud5</artifactId>
        <groupId>com.atguigu</groupId>
        <version>1.0-SNAPSHOT</version>
    </parent>
    <modelVersion>4.0.0</modelVersion>

    <artifactId>cloudalibaba-config-nacos-client3377</artifactId>
    <dependencies>
        <!--nacos-config-->
        <dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-nacos-config</artifactId>
        </dependency>
        <!--nacos-discovery-->
        <dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
        </dependency>
        <!--web + actuator-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        <!--一般基础配置-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>



</project>
```



### 2.3 yml

```yml
# nacos配置


spring:
  application:
    name: nacos-config-client
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848 #Nacos服务注册中心地址
      config:
        server-addr: localhost:8848 #Nacos作为配置中心地址
        file-extension: yml #指定yml格式的配置
        namespace: 450a01ec-ef71-41dd-a419-8b1af1098b79
        group: TEST_GROUP

management:
  endpoints:
    web:
      exposure:
        include: '*' #重要
# ${spring.application.name}-${spring.profile.active}.${spring.cloud.nacos.config.file-extension}
# nacos-config-client-dev.yml

# nacos-config-client-test.yml   ----> config.info
```

然后通过

curl -X POST "http://localhost:3377/actuator/refresh 实现动态刷新





| 参数     | 描述                                                         |
| -------- | ------------------------------------------------------------ |
| events   | 一个或多个用空格分隔的事件类型和可选的命名空间。             |
| selector | 可选。一个选择器字符串，用以过滤选定的元素，该选择器的后裔元素将调用处理程序。 如果选择是空或被忽略，当它到达选定的元素，事件总是触发。(只允许该子元素的所有选择器) |
| data     | 可选。作为event.data属性值传递给事件对象的额外数据对象以供事件处理函数处理。 |
| fn       | 该事件被触发时执行的函数。 false值也可以做一个函数的简写，返回false。 |

```js
$(document).ready(function(){ 
  var newtext="这是新文本" 
  $("div").on("click",{"mytext":newtext},function(e){ 
    $(this).text(e.data.mytext); 
  }) 
}) 
```

## 3 利用hutool封装的一些常用工具类

```xml
<dependency>
            <groupId>cn.hutool</groupId>
            <artifactId>hutool-all</artifactId>
            <version>5.1.0</version>
        </dependency>
```





https://hutool.cn/docs/#/



# idea一些快捷键的使用

![image-20210223112250250](imgs/image-20210223112250250.png)

## ctrl+alt+f7(当前方法的所有使用情况的位置信息)



## ctrl+alt+j(合并成一行)



## ctrl + alt + 鼠标右键(快速进入方法的实现类)





# linux语句总结的技巧

## 后面加入grep -v grep来排除干扰

ps -ef | grep activemq | grep -v grep

![image-20210309145348772](imgs/image-20210309145348772.png)

$()可以用来先行执行,例如

```
 docker rmi -f $(docker images -qa)
$(docker images -qa)代表先在容器中取出

```

![image-20210419132230241](imgs/image-20210419132230241.png)

然后把输出的结果这两个id值传入docker rmi语句中取实现删除

## 删除所有占用的端口号的进程

```
lsof -i :4002|grep -v "PID"|awk '{print "kill -9",$2}'|sh
```







# idea 总结的一些技巧

更改idea 使其提示



![image-20210310215623043](imgs/image-20210310215623043.png)

## 1 idea 复制一个maven工程

### 1 改掉依赖

![image-20210314104135958](imgs/image-20210314104135958.png)

### 2 改掉名字

![image-20210314104339722](imgs/image-20210314104339722.png)

![image-20210314104406299](imgs/image-20210314104406299.png)

## 2 虚拟端口映射

或者取巧不想新建重复体力劳动，可以利用IDEA功能，直接拷贝虚拟端口映射



![image-20210321164529984](imgs/image-20210321164529984.png)

## 3 如何通过jar包进行执行main方法

通过maven进行打包

然后在maven包下面的META-INF下面的MANIFEST.MF里面添加Main-Class: tools,其中tools方法里面有者主方法

然后注意:最下面写好这句话,光标要在这句话的下面,不然没有用处

![image-20210419114552478](imgs/image-20210419114552478.png)







## 4 使用mysql提示进行代码的编写

![image-20210514212733315](imgs/image-20210514212733315.png)

# 总结的一些技巧非java

## 如何完美的复制csdn内容到md中

## 

通过找到article_content标签,下面的内容,进行

![image-20210414095639563](imgs/image-20210414095639563.png)

**copy-copyelement**

利用转换工具进行转换

https://sitdown.mdnice.com/Demo.html

提升标题和降低标题

```java


import java.io.*;

/**
 * @author 10185
 * @create 2021/4/14 22:36
 */
public class tools {


        public static void main(String[] args) throws FileNotFoundException {
            //获取要读取的文件
            File readFile=new File(args[0]);
            //输入IO流声明
            InputStream in=null;
            InputStreamReader ir=null;
            BufferedReader br=null;
            FileOutputStream out = new FileOutputStream(args[1]);

            try {
                //用流读取文件
                in=new BufferedInputStream(new FileInputStream(readFile));
                //如果你文件已utf-8编码的就按这个编码来读取，不然又中文会读取到乱码
                ir=new InputStreamReader(in,"utf-8");
                //字符输入流中读取文本,这样可以一行一行读取
                br= new BufferedReader(ir);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(out);
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(bufferedOutputStream);
                BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
                String line="";
                //一行一行读取
                while((line=br.readLine())!=null){
                    //一行行取出
                    //如果遇到不是#符号,就中断
                    if (line.length() == 0) {
                        bufferedWriter.newLine();
                        bufferedWriter.flush();
                        continue;
                    }
                    if (line.charAt(0) == '#') {
                        //如果第一个数是'#',说明是标题,可以进行操作
                        //把标题升级一级
                        line = "#"+line;
                    }
                    //进行输出
                    bufferedWriter.write(line);
                    bufferedWriter.newLine();
                    bufferedWriter.flush();


                }

            } catch (Exception e) {

                e.printStackTrace();
            }finally{
                //一定要关闭流,倒序关闭
                try {

                    if(br!=null){
                        br.close();
                    }
                    if(ir!=null){
                        ir.close();
                    }
                    if(in!=null){
                        in.close();
                    }
                } catch (Exception e2) {

                }

            }

        }




}

```

![image-20210415124112386](imgs/image-20210415124112386.png)

# 总结复制mysql表结构

```mysql
SELECT
COLUMN_NAME 字段名称,
COLUMN_TYPE 数据类型,
IF(IS_NULLABLE='NO','是','否') AS '必填',
COLUMN_COMMENT 注释
FROM
INFORMATION_SCHEMA.COLUMNS
where
-- Finance为数据库名称，到时候只需要修改成你要导出表结构的数据库即可
table_schema = 'mickey' AND table_name = 'user_info'

```

