# 遇到的错误总结

## 1.龟兔赛跑里的while语句缓存问题

```java
package com.threadTest1;

public class Test3 {
    public static void main(String[] args) {
        int a = 30;
        Sport a1 = new Sport("兔子", 100, 10000);
        Sport a2 = new Sport("乌龟", 1000, 1000);

        a1.start();
        a2.start();
        while (true) {//让主方法一直去判断，如果不写执行一次就结束了
            //cpu频繁的在拿finish变量的值，判断，发现变量值没有变化，很短的时间里取了1000次10000次，做了一个优化，把变量值缓存起来了，放在了缓存里了，同步一次要很长时间
            //所以出现与实际值不同的情况
            //用volatile修饰符可以不缓存，直接去栈里面取

            if (!a1.isFinish() || !a2.isFinish() ){
                a1.interrupt();
                a2.interrupt();
                a1.stop();
                a2.stop();
                break;
            }
        }
    }
}

class Sport extends Thread {
    int xiao;
    int b;
    volatile boolean finish = true;
    boolean stop = true;

    public Sport(String name, int xiao, int b) {
        super(name);
        this.xiao = xiao;
        this.b = b;
    }

    @Override
    public void run() {

            int i;
            for (i = 1; i <= 30 && stop; i++) {
                try {
                    Thread.currentThread().sleep(xiao);
                    System.out.println(getName() + "走了" + i + "米");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (i == 10 || i == 20) {
                    try {
                        System.out.println(getName() + "在休息");
                        Thread.currentThread().sleep(b);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        if (i > 30) {
            finish = false;
            System.out.println(getName()+"胜利");
        }


    }

    public boolean isFinish() {
        return finish;
    }

    public void setStop(boolean stop) {
        this.stop = stop;
    }
}
```

## web工程重命名后无法连上，出现404错误

总结：把iml文件相关错误的路径改回来，就可以正常使用了



## jsp请求转发前面不能有flush

1.转发之前不能运行response.getWriter().close()或者flush()，由于一次浏览器请求仅仅能做出一次响应，运行这个，会直接响应给浏览器，也就不会做后面的转发或其它动作。



## 先访问servlet获取request数据，然后再访问jsp程序，来进行操作



## 在<c:forword>标签中 begin和end里面有空格，导致错误

## 注意反射获取方法需要用到getDeclaredMethod



## 改完数据记得保存到数据库中，不然就错了

## 重定向记得return

## 在javaScript中key的值有.记得用中括号包起来

## 在mybatis中搭建环境要注意resources里面的资源文件包要设置的和java类包一样

不能连写,要一块一块写,如果一起写，会出现

![image-20201105093846239](imgs/image-20201105093846239.png)

如果分开写，那就是![image-20201105093934013](imgs/image-20201105093934013.png)



## 在mapreduce字符串的写法是WriteUTF();默认的分组是由compare排序相等的分为一组



## mapreduce中的reduce中的问题

注意mapreduce中的reduce里面的map集合中的key和value都是同一个对象，通过改变其值来改变里面的内容，里面的对象都是同一个，因此通过集合来进行排序的时候，需要通过beanutils中的拷贝方法来进行拷贝。

## spring默认要使用接口自动注入

org.springframework.beans.factory.UnsatisfiedDependencyException: Error creating bean with name 'com.atguigu.test.myTest1': Unsatisfied dependency expressed through field 'adminServiceImpl'; nested exception is org.springframework.beans.factory.BeanNotOfRequiredTypeException: Bean named 'adminServiceImpl' is expected to be of type 'com.atguigu.crowd.service.impl.AdminServiceImpl'

如果spring有实现的接口的化，那么就是jdk动态代理对象,如果有多个实现类，就使用Qualifier来指定id值
如果没有实现接口，那么就用cglib进行动态代理（前提是一定要导入包)



```
@Autowired
    @Qualifier("adminServiceImpl")
    AdminService adminServiceImpl;
```

正确这样

```
@Autowired
@Qualifier("adminServiceImpl")
AdminService adminServiceImpl;
```

要想有接口的adminServiceImpl

比如这样

@Autowired

adminServiceImpl adminServiceImpl;

必须在配置文件里面写

```
<aop:aspectj-autoproxy proxy-targe-class="true"/>
```

**注意：一定要用adminService接口，不然会报错，因为默认使用jdk动态代理，一定要有接口,如果没有实现类才会使用cglib动态代理**



## 页面中用EL表达式获取的数据是用setAttribute方法来获取request保存的数据,因此不能获取自己jsp发送到servlet中的请求参数

可以用这个

```
${param.loginAcct}
```

## 表单重复提交

![image-20210206210436070](imgs/image-20210206210436070.png)

代码

```java
$(function () {
  //第一个参数是
  $("#rolePage").on("click", ".update", function () {
    $("#updateModal").modal("show");
    //this表示正在调用这个对象的标签
    let name = $(this).parent().prev().text();
    $("#updateModal [name = roleName]").val(name);
    window.roleId = $(this).attr("id");
    $("#updateRoleBtn").click(function () {
      //获取name = roleName的值

      let val = $("#updateModal [name=roleName]").val();
      $.ajax({
        url: "role/update/ssm.json",
        data: {"name": val, "id": window.roleId},
        type: "post",
        dataType: "json",
        success: function (data) {
          if (data.result === "SUCCESS") {
            layer.msg("修改成功");

            getPage();
          } else {
            layer.msg("修改失败,失败原因为：" + data.message)
          }
        },
        error: function (data) {
          layer.msg(data.statusMessage)
        }


      });
      //手动关闭隐藏页

      $("#updateModal").modal("hide");
```

pathVariable请求路径错误问题

```java
@RequestMapping(value = "/assignSaveAdmin/{adminId}/{pageNum}/{keyword}.html",method = RequestMethod.POST)
public String assignSaveAdmin(Model model, @PathVariable("adminId") Integer id, @PathVariable("pageNum") Integer pageNum, @PathVariable("keyword") String keyword, @RequestParam("ids") Integer[] ids) {
```

//如果中间adminId出现空值的情况,那么请求路径就变成//了,因此要把可能出现空指针的值放到后面或者可以指定多个匹配路径

```
@RequestMapping(value = {"/get/{userId}", "/get/{id}/{userId}"}, method = RequestMethod.GET)
```



## 只能是组件才能使用@Autowired完成自动注入,同时也需要@Autowired组件才能注册组件中的@Autowired

@Bean里面不能用@Autowired的方式进行注入组件

应该用这种方式进行赋值

```java
@Bean
public MapperScannerConfigurer mapperScannerConfigurer(MyInterceptor myInterceptor) {
    MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
    System.out.println("开始注册组件111"+myInterceptor);
    mapperScannerConfigurer.setBasePackage("com.atguigu.boot.mapper");
    return mapperScannerConfigurer;
}
```



## 如果使用了负载均衡不能用http://localhost:8001/payment/zipkin



需要使用http://CLOUD-PAYMENT-SERVICE/payment/zipkin

eureka默认将服务名称转化为大写，且ribbon在负载均衡时仅识别eureka中的大写服务，所以消费端的url前缀为大写的YOUR-SERVICE



## 注意:mysql里面设置了GRANT REPLICATION SLAVE ON *.* TO 'root'@'%' IDENTIFIED BY '123123'; 表示只能远程进行访问



## 注意vue脚本需要引入到html页面主题的后面



# 注意thymeleaf判断需要注意数据的类型



# 遇到的异常总结

## 1.java.util.ConcurrentModificationException

因为在foreach迭代的同时调用的是迭代器方法，一旦开始迭代就不能对里面的元素进行修改，因此如果要在迭代器中进行删除的时候，就要使用iterator里面的remove方法，这样就能对里面的元素进行修改

## 2.java.io.EOFException

```java
	java.io.EOFException异常

	这是由于文件里本身没有数据，反序列化数据造成异常
	public void FrmFile(){
     File myfile = new File("User.txt");
   try{
            FileInPutStream fis = new FileInPutStream(myfile);
           ObjectInPutStream ois = new ObjectInPutSrtream(fis);
           user.List = ois.readObject();  //异常是在这步提出的。提出异常试音为当时User.txt刚刚建立，内容为空，ois读不到东西所以报出异常,因此可以加一个判断语句，如果没有就退出
           fis.close();
           ois.close();
       }
   catch(Exception e){
      e.printStackTrace;
   }
   
}

```



## 3.java.lang.IllegalMonitorStateException

​             Integer aaa  ;
​                aaa++;
​                a.set(0,aaa);
​                a.notify();//其中这个a变量不能改变，一定要是固定的不然会报这个错误
​				不能用Integer这种包装类，可以用lists，或者自己创造
​				一个类   因为根据jdk的void notifyAll()的描述，
​				“解除那些在该对象上调用wait()方法的线程的阻塞状态。
​				该方法只能在同步方法或同步块内部调用。
​				如果当前线程不是对象所得持有者，
​			该方法抛出一个java.lang.IllegalMonitorStateException 异常”

总结：不能使用像integer这种会变得量



## 4、Exception in thread "main" java.net.SocketException: socket closed

```java
 @Override
    public void run() {
        try {
            PrintStream printStream = new PrintStream(socket.getOutputStream());
            Scanner s = new Scanner(System.in);
            while (true) {
                System.out.println("请输入你想要发的话");
                String str = s.next();
                printStream.println(str);
                if ("bye".equals(str)) {
                    break;
                }
            }
           // printStream.close();//不能提前关掉printStream，否则会报错，因为服务器还在接受信息，关闭会报Exception in thread "main" java.net.SocketException: socket closed
		   Java的socket是一个全双工套接字，任何的输入流或输出流的close()都会造成Socket关闭。

            s.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
```



## 5.getPost中遇到的空指针问题

```java
 @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");//记得一定要加上字符集
        System.out.println(req.getParameter("用户名"));
        System.out.println(req.getParameter("密码"));
        String[] hobby = req.getParameterValues("兴趣爱好");
        List<String> strings = Arrays.asList(hobby);
       System.out.println(strings);
    }
}
```

当执行如下代码的时候，在Arrays.asList(hobby)遇到了空指针异常，而且上面输出的值全部为空

总结：

记得一定要加上字符集解决中文乱码问题。因为中文不识别，所以req.getParameter不能识别，所以输出一直为空，所以还是尽量避免中文



## 6.Exception in thread "main" java.lang.NoClassDefFoundError: org.springframework.beans.FatalBeanException

 已经用把factory对象交给Spring

```java
  public static void main(String[] args) {
        ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("one.xml");
        Object factory = classPathXmlApplicationContext.getBean("factory");
        System.out.println(factory);
    }
}
```

然后Myfactory又调用了

```java
public Student getObject() throws Exception {
    ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("bean.xml");
    return classPathXmlApplicationContext.getBean(Student.class);
}
```

报这个异常

## 7 NoSuchBeanDefinitionException

因为如果只有一个有参构造的时候，不需要写@Autowired，会自动注入，因此这个有参构造里面的参数一定要是@Component被Spring知道

```java
@Component
public class Teacher {
```

```java
@Component
public class User {

    private Teacher teacher;
    
    public User(Teacher teacher) {
        this.teacher = teacher;
    }
```

这样也可以自动注入

## 8 java.lang.NoSuchMethodError

多半是因为maven依赖导致的版本冲突

## 9 spring默认要使用接口自动注入

因为serviceimpl参加了事务管理,用了aop自动代理,默认使用的是jdk自带的方式,因为这个serviceImpl有实现类,用了jdk自动代理的方式,因此不成功

解决方法:

1:

删掉接口,没有接口自动用cglib方式进行处理,<aop:aspectj-autoproxy>

2:

变成接口的方式

3:

强制使用cglib方式进行处理

```
<aop:aspectj-autoproxy proxy-targe-class="true"/>
```

4:

不进行动态代理



org.springframework.beans.factory.UnsatisfiedDependencyException: Error creating bean with name 'com.atguigu.test.myTest1': Unsatisfied dependency expressed through field 'adminServiceImpl'; nested exception is org.springframework.beans.factory.BeanNotOfRequiredTypeException: Bean named 'adminServiceImpl' is expected to be of type 'com.atguigu.crowd.service.impl.AdminServiceImpl'

如果spring有实现的接口的化，那么就是jdk动态代理对象,如果有多个实现类，就使用Qualifier来指定id值
如果没有实现接口，那么就用cglib进行动态代理（前提是一定要导入包)



```
@Autowired
    @Qualifier("adminServiceImpl")
    AdminService adminServiceImpl;
```

正确这样

```
@Autowired
@Qualifier("adminServiceImpl")
AdminService adminServiceImpl;
```

要想有接口的adminServiceImpl

比如这样

@Autowired

adminServiceImpl adminServiceImpl;

必须在配置文件里面写

```
<aop:aspectj-autoproxy proxy-targe-class="true"/>
```

**注意：一定要用adminService接口，不然会报错，因为默认使用jdk动态代理，一定要有接口,如果没有实现类才会使用cglib动态代理**

## 10 **HttpMediaTypeNotAcceptableException**

```
@RequestMapping("/getTree/ssm.json")
public ResultEntity<List<Auth>> getTree() {
    List<Auth> allAuth = authService.getAllAuth();
    return ResultEntity.successWithData(allAuth);


}
```

返回json,@requestMapping需要是("/getTree/ssm.json")不是ssm.html

# 关于java中一些特定情况的解决方式

## 1.关于将Set集合转换成List集合

```java
Set<String> set = new HashSet<>();
List<String> myList = new ArrayList<>(set);
//将Set集合转换成List集合
```

## 2.synchronized的三种写法

synchronized有三种写法：
	第一种：同步代码块
		灵活
		synchronized（线程共享对象）{
			同步代码块；
		

```java
synchronized有三种写法：
	第一种：同步代码块
		灵活
		synchronized（线程共享对象）{
			同步代码块；
}
第二种：在实例方法上使用synchronized
	表示共享对象一定是this
	并且同步代码块是整个方法体
第三种：在静态方法上使用synchronized
	表示找类锁
	类锁永远只有一把
	就算创建了100个对象，那类锁也只有一把

   对象锁：一个对象一把锁，100个对象100把锁
   类锁：100个对象，也可能只是一把类锁。
	有synchronized必然要找当前对象的锁，没有synchronized则不需要找锁
```
## 3.如何将StringBuffer转换成String

StringBuffer a = new StringBuffer();

System.out.pringln(a.toString);











# 4.java中遇到的问题

## 关于Jquary里面的this对象

.click(function(){

​	 在事件响应的function函数中，有一个this对象，这个this对象是当前正在相应事件的dom对象

})

但是

.click(function(){

​	deleteFun();//在函数里调用这个方法，这个方法里面的this属性不是正在相应当前事件的dom对象，是一个完全不同的对象

})

## 关于idea中的缓存的问题

否则那样会将使用被复制文件的那些地方 文件名会变成复制后的那个 而路径是原来的 所以会导致找不到文件

所以绝对不要直接复制文件或者包或者目录到项目中的另一处 需要时应该新建文件 把代码复制进去

如果实在找不到问题，可以rebuild工程，然后重新部署项目

## maven包已经导入了无法识别

更新maven包如果不行

Mybatis 出现org.apache.ibatis.io不存在，org.apache.ibatis.session不存在等错误

 

![这是我遇到的](https://www.pianshen.com/images/740/c4976c930868fb2faf0a348fdb2bf3e4.png)

解决方法：

### 第一步

![在这里插入图片描述](https://www.pianshen.com/images/627/2c35c7abccbdaf40b66c9b6ded684dfb.png)

### 第二步：点击蓝色的选项

![在这里插入图片描述](https://www.pianshen.com/images/764/db0eedb792d4636d08b1cc4fbb93b78c.png)

### 第三步：重启后，打开下面的Terminal

- 分别输入以下命令：
- mvn idea:idea
- mvn clean
- mvn test
- 执行完上述命令后一般就会解决问题
- 注意：在上述命令中如果有某个命令在执行过程中，出现错误，请新建一个项目，将原有文件复制过去再执行上述命令
  ![在这里插入图片描述](https://www.pianshen.com/images/541/2715dd1ea1822f03aca7059e3012d215.png)
  ![在这里插入图片描述](https://www.pianshen.com/images/900/271a0fb2feb22401ff7844ada1a8731c.png)



## hadoop集群集群配置完成之后不能进入webapp

无法查看SecondaryNameNode所在节点网页解决方法
**解决办法：**
路径：$HADOOP_HOME/share/hadoop/hdfs/webapps/static
查看dfs-dust.js的第61行

```
   'date_tostring' : function (v) {
	  return moment(Number(v)).format('ddd MMM DD HH:mm:ss ZZ YYYY');
	},
并修改函数返回值：

'date_tostring' : function (v) {
  return new Date(Number(v)).toLocaleString();
},
12345678
```

修改之后，页面正确：

## el 表达式用变量接受

```
<script>
    $(function () {
        <c:if test="${! empty requestScope.exception}">
            var a = "${requestScope.exception.message}";
            layer.msg(a);
        </c:if>


    })
```

el表达式里面的数据相当于一个文字,因此要转成字符串进行接受







# 5.java中要的操作

## 5.1 加入jar包

新建一个lib包，将jar包复制到lib包里面

![image-20201014085725100](imgs/image-20201014085725100.png)

然后右键最下面有一个addlibrary

<img src="imgs/image-20201014085917872.png" alt="image-20201014085917872" style="zoom:33%;" />

加入成功dom4j-1.6.1.jar 前面有一个三角形，代表里面有东西了

## 

## 5.2 idea中怎么恢复文件

![image-20201107193121710](imgs/image-20201107193121710.png)

或者

![image-20201107193146316](imgs/image-20201107193146316.png)

![image-20201107193202356](imgs/image-20201107193202356.png)

# 6.java中需要注意的事项

## sql中要注意的事项

在jdbc中，sql会把java客户端中的语句把双引号去掉，然后在进行相应的操作

比如说：客户端中出现了"小迪迪",sql会先把双引号去掉，变成小迪迪,最后再加上单引号

两种情况下不能用通配符进行赋值

一种就是where id in

一种就是模糊查询，但是可以通过拼接的方式进行查询

"select * from user where id in ?" 如果？有多个就变成了

select * from user where id in '3,4,5'就只删除第一个了

select * from user where name like '%?%'；//不能使用
select * from user where name like concat ('%',?,'%')





## thymeleaf只能解析在templates文件下面的文件

# 7 idea更改的快捷键

ctrl+shift+f9     ->      ctrl+shift+Q  

ctrl+del原本是删除文本最后一个字母,现在改成关闭文件

ctrl + f4 改成关闭所有文件

alt+j(操作最近几排相同的字段)  -> alt + k

alt+D(gson插件的使用) -> alt + f

alt+k原本是选择下一个匹配的字符(像ctrl+f这种匹配出来的选择下一个)->alt+I



# 8 idea中添加的快捷键

向上/下/左/右箭头添加alt+asdw

ctrl+alter添加alt+j

alter添加alt+k

