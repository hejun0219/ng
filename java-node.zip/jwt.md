登录验证

用户登录验证

用户输入用户名和密码，发送给服务器。

服务器验证用户名和密码，正确的话就返回一个签名过的token（token 可以认为就是个长长的字符串），浏览器客户端拿到这个token。

后续每次请求中，浏览器会把token作为http header发送给服务器，服务器验证签名是否有效，如果有效那么认证就成功，可以返回客户端需要的数据。

一旦用户退出登录，只需要客户端销毁token即可，服务器端不需要任何操作。

优缺点：

JWT是json web token缩写。它将用户信息加密到token里，服务器不保存任何用户信息。服务器通过使用保存的密钥验证token的正确性，只要正确即通过验证。 优点是在分布式系统中，很好地解决了单点登录问题，很容易解决了session共享的问题。jwt长度较小，且可以使用URL传输(URLsafe)。

验证token的过程其实跟重新生成一个token的过程是一样的

```java
/** 生产 token */
public static String generateToken(Map<String, Object> claimMaps) {

    if (null != claimMaps) {
        claimMaps.forEach((key, val) -> {
            claimMaps.put(key, val.toString());
        });
    }

    return Jwts.builder()
            // JWT_ID,可用于每次签名唯一识别
            .setId(UUID.randomUUID().toString())
            // 数据压缩方式
            .compressWith(CompressionCodecs.GZIP)
            // 签发者信息
            .setIssuer(ISSUER)
            // 说明
            .setSubject("system")
            //接收用户
            .setAudience(AUDIENCE)
            // 签发时间
            .setIssuedAt(new Date(System.currentTimeMillis()))
            // 过期时间戳
            .setExpiration(new Date(System.currentTimeMillis() + EXPIRES_IN * 1000))
            // claim信息,自定义载荷
            .addClaims(claimMaps)
            // 签名算法以+密匙
            .signWith(SIGNATURE_ALGORITHM, secretKey)
            .compact();
}
```

根据传递过来的header、payload以及服务端存储的密钥，重新生成一个token对比，如果token相同，那么标志token有效，没被修改。同时如果token没被修改，还可以进一步同bease64解密payload，然后根据payload中的exp有效期信息，判断token是否已经过期

![å¨è¿éæå¥å¾çæè¿°](imgs/clip_image002.png)

 

 JWT可以同时使用在web环境和RESTfull的接口。 缺点是无法作废已颁布的令牌/不易应对数据过期。

输入用户名和密码，发送给服务器。

服务器验证用户名和密码，正确的话就返回一个签名过的token（token 可以认为就是个长长的字符串），浏览器客户端拿到这个token。

后续每次请求中，浏览器会把token作为http header发送给服务器，服务器验证签名是否有效，如果有效那么认证就成功，可以返回客户端需要的数据。

一旦用户退出登录，只需要客户端销毁token即可，服务器端不需要任何操作。

优缺点：

JWT是json web token缩写。它将用户信息加密到token里，服务器不保存任何用户信息。服务器通过使用保存的密钥验证token的正确性，只要正确即通过验证。 优点是在分布式系统中，很好地解决了单点登录问题，很容易解决了session共享的问题。jwt长度较小，且可以使用URL传输(URLsafe)。

验证token的过程其实跟重新生成一个token的过程是一样的

 

根据传递过来的header、payload以及服务端存储的密钥，重新生成一个token对比，如果token相同，那么标志token有效，没被修改。同时如果token没被修改，还可以进一步同bease64解密payload，然后根据payload中的exp有效期信息，判断token是否已经过期

 

 JWT可以同时使用在web环境和RESTfull的接口。 缺点是无法作废已颁布的令牌/不易应对数据过期。

1、 JWT的最大缺点是服务器不保存会话状态，所以在使用期间不可能取消令牌或更改令牌的权 限，一旦JWT签发，在有效期内将会一直有效。2、JWT本身包含认证信息，因此一旦信息泄露，任何人都可以获得令牌的所有权限。3、为了减少盗用和窃取，JWT不建议使用HTTP协议来传输代码，而是使用加密的HTTPS协议进行 传输。4、JWT不仅可用于认证，还可用于信息交换，善用JWT有助于减少服务器请求数据库的次数。

  

单点登陆

无法放开首页

支持跨域

springSession

支持父域，服务器端无法进行清除

